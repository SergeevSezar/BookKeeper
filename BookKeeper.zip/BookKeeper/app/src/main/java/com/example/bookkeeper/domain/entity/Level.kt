package com.example.bookkeeper.domain.entity

enum class Level {
    TEST,
    EASY,
    NORMAL,
    HARD
}